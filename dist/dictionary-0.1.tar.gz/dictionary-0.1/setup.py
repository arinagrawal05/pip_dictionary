from setuptools import setup, find_packages

setup(
    name="dictionary",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        # "pyperclip",
        # "difflib",
        # "tkinter"
        
    ],
   include_package_data=True,  # This line includes non-code files
    package_data={
        '': ['data.json'],  # Include data.json
    },    entry_points={
        'console_scripts': [
            'dictionary=main:main',  # Assuming you have a main function in main.py
        ],
    },
    description="A speaking dictionary application with text-to-speech functionality.",
    long_description=open('README.md').read(),
    # long_description_content_type='text/markdown',
    author="Arin Agrawal",
    author_email="arindeveloper05@gmail.com",
    url="https://github.com/arinagrawal05/pip_dictionary",  # Update with your URL
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",  # Update based on your license
    ],
    python_requires='>=3.6',  # Specify your Python version compatibility

)
