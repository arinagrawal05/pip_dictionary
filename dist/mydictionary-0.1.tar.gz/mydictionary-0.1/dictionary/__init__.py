from .dictionary import Dictionary
from .gui import GUI
