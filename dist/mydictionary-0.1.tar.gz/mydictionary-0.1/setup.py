from setuptools import setup, find_packages

setup(
    name="mydictionary",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        "pyperclip",
        # "difflib",
        # "tkinter"
    ],
    include_package_data=True,
    entry_points={
        'console_scripts': [
            'dictionary=main:main',  # Assuming you have a main function in main.py
        ],
    },
    description="A speaking dictionary application with text-to-speech functionality.",
    long_description=open('README.md').read(),
    # long_description_content_type='text/markdown',
    author="Your Name",
    author_email="your.email@example.com",
    url="https://github.com/arinagrawal05/pip_dictionary",  # Update with your URL
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",  # Update based on your license
    ],
    python_requires='>=3.6',  # Specify your Python version compatibility

)
